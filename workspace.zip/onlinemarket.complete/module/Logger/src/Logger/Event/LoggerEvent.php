<?php
namespace Logger\Event;

class LoggerEvent
{
    const LOGGER_LOG = 'logger.log';
}