<?php
namespace Application;

use DateTime;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Zend\ModuleManager\ModuleManager;
use Zend\Session\Container;
use Zend\EventManager\GlobalEventManager;

class Module
{
    
    public function init(ModuleManager $mm)
    {
        $eventManager = $mm->getEventManager();
        $shared = $eventManager->getSharedManager();
        // NOTE: uncomment the line below and test by making a browser request
        //$shared->attach('*', '*', array($this, 'onTest'), 10);
        // demonstrates usage of the GlobalEventManager
        GlobalEventManager::attach('logSomething', [$this, 'onLog'], 1);
    }
    
    public function onBootstrap(MvcEvent $e)
    {
        $eventManager        = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
        $eventManager->attach(MvcEvent::EVENT_DISPATCH, [$this,'onDispatch'], 100);
        // NOTE: you can uncomment the line below to trap 404 and general dispatch errors
        //$eventManager->attach(MvcEvent::EVENT_DISPATCH_ERROR, [$this, 'onError'], 100);
    }

	public function onTest($e)
	{
        printf("<br>%10s : %30s : %30s\n", $e->getName(), get_class($e), get_class($e->getTarget()));
	}
        
	public function onError(MvcEvent $e)
	{
        // set categories
        $this->onDispatch($e);
		// get view model + set variable for categories
        $viewModel = $e->getViewModel();
        $viewModel->setTemplate('error/alt-error');
        $viewModel->setVariable('message', '<h3>Hmmmm ... <br>we seem to have <br>encountered an error!</h3>');
	}
        
    public function onDispatch(MvcEvent $e)
    {
        $svcMgr = $e->getApplication()->getServiceManager();
        $viewModel = $e->getViewModel();
        $viewModel->setVariable('categories', $svcMgr->get('application-categories'));
    }

    // NOTE: make sure data/log exists + the app has read/write privileges
    public function onLog($e)
    {
        $message = $e->getParam('message') . ':' . date('Y-m-d H:i:s'). PHP_EOL; 
        //error_log($message, 3, '/tmp/event.log');
        error_log($message);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return ['Zend\Loader\ClassMapAutoloader' => [__DIR__ . '/autoload_classmap.php']];
    }
   

    public function getServiceConfig()
    {
        return [
			'services' => [
				'application-test' => [__FILE__ => microtime(TRUE)],
			],
            'factories' => [
                'application-session' => function ($sm) {
                    return new Container('onlineMarket');
                },
            ],
        ];
    }
}
