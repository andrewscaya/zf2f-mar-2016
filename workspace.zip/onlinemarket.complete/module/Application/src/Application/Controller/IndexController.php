<?php
namespace Application\Controller;

use Market\Model\ListingsTable;
use Zend\View\Model\ViewModel;
use Zend\EventManager\GlobalEventManager;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Db\TableGateway\Feature\RowGatewayFeature;

class IndexController extends AbstractActionController
{

    public function indexAction()
    {
        $viewModel = new ViewModel(['test' => $this->getServiceLocator()->get('application-test')]);
        $viewModel->setTemplate('application/index/index');
        return $viewModel;
    }

    public function globalAction()
    {
        GlobalEventManager::trigger('logSomething', $this, ['message' => __METHOD__]);
        $viewModel = new ViewModel(['test' => 'Now have a look at the PHP error log']);
        $viewModel->setTemplate('application/index/index');
        return $viewModel;
    }

    /**
     * Updates expired date
     */
    public function updateAction()
    {
        $test  = '';
        $table = new ListingsTable(ListingsTable::TABLE_NAME, 
                                   $this->getServiceLocator()->get('general-adapter'),
                                   new RowGatewayFeature(ListingsTable::PRIMARY_KEY));
        foreach ($table->select() as $row) {
            $expDate = new \DateTime('now');
            $expDate->add(new \DateInterval(sprintf('P%dD', rand(0,999))));
            $row->date_expires = $expDate->format('Y-m-d');
            $row->save();
            $test .= sprintf('%30s:%30s' . PHP_EOL, $row->title, $row->date_expires);
        }
        $viewModel = new ViewModel(['test' => $test, 'date' => $expDate]);
        $viewModel->setTemplate('application/index/index');
        return $viewModel;
    }
}
