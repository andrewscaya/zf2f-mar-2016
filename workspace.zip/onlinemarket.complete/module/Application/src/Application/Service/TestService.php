<?php
/**
 * Demonstrates that implementing InitProviderInterface
 * the defined method init() will be automatically invoked
 * as long as this class is retrieved via the service manager
 * 
 * To Test: /application/test-service
 */ 
namespace Application\Service;

use Zend\ModuleManager\Feature\InitProviderInterface;
use Zend\ModuleManager\ModuleManagerInterface;

class TestService implements InitProviderInterface
{
    public function init(ModuleManagerInterface $mm)
    {
        echo get_class($mm);
        echo '<br>';
        echo __METHOD__;
    }
}
