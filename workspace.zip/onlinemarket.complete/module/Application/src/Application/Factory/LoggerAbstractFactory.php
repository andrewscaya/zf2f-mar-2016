<?php
namespace Application\Factory;

class LoggerAbstractFactory
{
    public function canCreateServiceWithName(ServiceLocatorInterface $services)
    {
    	// see /path/to/onlinemarket/config/autoload/db.local.php
        $adapter   = $services->get('general-adapter');
        return new ListingsTable($adapter);
    }
}
