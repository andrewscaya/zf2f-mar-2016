<?php
namespace Market\Form;

use Zend\InputFilter\Input;
use Zend\Validator;
use Zend\Filter;
use Zend\InputFilter\InputFilter;
use Zend\Validator\Db\RecordExists;

class DeleteFilter extends InputFilter
{
    
    protected $dbValidatorParams = array();
    
	public function buildFilter()
	{
		$id = new Input('itemId');
		$id->getFilterChain()
		   ->attachByName('Int');
        $id->getValidatorChain()
           ->attach(new RecordExists($this->dbValidatorParams));
           
		$delCode = new Input('delCode');
		$delCode->getValidatorChain()
				->addByName('Alnum');
		
		$this->add($id)
			 ->add($delCode);
	}
    
    public function setDbValidatorParams($params)
    {
        $this->dbValidatorParams = $params;
    }
    
} 
