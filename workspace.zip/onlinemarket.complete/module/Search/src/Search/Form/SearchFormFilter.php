<?php
namespace Search\Form;

use Zend\InputFilter\Input;
use Zend\Validator;
use Zend\Filter;
use Zend\InputFilter\InputFilter;
// custom filter
use Search\Filter\Float;

class SearchFormFilter extends InputFilter
{
	public function prepareFilters(Array $categories)
	{
		$category = new Input('category');
		$category->setAllowEmpty(TRUE);
		$category->getFilterChain()
				 ->attach(new Filter\StringToLower());
		
		$title = new Input('title');
		$title->setAllowEmpty(TRUE);

		$priceMin = new Input('priceMin');
		$priceMin->setAllowEmpty(TRUE);
		$priceFilter = new Float();
		$priceMin->getFilterChain()
				 ->attach($priceFilter);
		
		$priceMax = new Input('priceMax');
		$priceMax->setAllowEmpty(TRUE);
		$priceFilter = new Float();
		$priceMax->getFilterChain()
				 ->attach($priceFilter);
		
		$expires = new Input('expires');
		$expires->setAllowEmpty(TRUE);
		
		$city = new Input('city');
		$city->setAllowEmpty(TRUE);
		
		$country = new Input('country');
		$country->setAllowEmpty(TRUE);
		$country->getFilterChain()
				->attachByName('StringToUpper');
		
		$name = new Input('name');
		$name->setAllowEmpty(TRUE);
  
		$phone = new Input('phone');
		$phone->setAllowEmpty(TRUE);
  
		$email = new Input('email');
		$email->setAllowEmpty(TRUE);
		
		$description = new Input('description');
		$description->setAllowEmpty(TRUE);
  
		$this->add($category)
			 ->add($title)
			 ->add($priceMin)
			 ->add($priceMax)
			 ->add($expires)
			 ->add($city)
			 ->add($country)
			 ->add($name)
			 ->add($phone)
			 ->add($email)
			 ->add($description);

        // globally apply StripTags and StringTrim
        $tags = new Filter\StripTags();
        $trim = new Filter\StringTrim();
        foreach ($this->getInputs() as $input) {
            $input->getFilterChain()->attach($tags)->attach($trim);
        }
             
	}
} 
