<?php
namespace Notification;

class NotificationEvent
{
    const NOTIFICATION_EVENT_NOTIFY     = 'notification.event.notify';
    const NOTIFICATION_EVENT_IDENTIFIER = 'notification.event.identifier';
}
