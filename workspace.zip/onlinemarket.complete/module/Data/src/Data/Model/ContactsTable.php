<?php
namespace Data\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;

class ContactsTable extends TableGateway
{
	public static $tableName  = 'contacts';
	public static $primaryKey = 'contacts_id';
	
	// key = form field; value = column name
	protected $formMappings = [
			'name' 			=> 'contact_name',
			'phone' 		=> 'contact_phone',
			'email' 		=> 'contact_email',
			'city' 			=> 'city',
			'country' 		=> 'country',
	];	
	
    /**
     * Returns the array of form --> database column mappings
     * 
     * @return array $formMappings
     */
    public function getFormMappings()
    {
        return $this->formMappings;
    }
    
	/**
	 * Inserts posting
	 * @param Array $data = uses form fields
	 * @return boolean $result = TRUE if operation was successful
	 */
	public function add($data)
	{
        // split city / country
        $data = $this->splitCityAndCountry($data);
		$insertData = array();
		foreach ($this->formMappings as $key => $value) {
			$insertData[$value] = $data[$key];
		}
		return $this->insert($insertData);
	}
	
	/**
	 * Updates posting
	 * @param int $id
	 * @param Array $data = uses form fields
	 * @return boolean $result = TRUE if operation was successful
	 */
	public function edit($id, $data)
	{
        // split city / country
        $data = $this->splitCityAndCountry($data);
		$insertData = array();
		foreach ($this->formMappings as $key => $value) {
			$insertData[$value] = $data[$key];
		}
		return $this->update($insertData, [self::$primaryKey => $id]);
	}

    /**
     * Splits city and country from "cityCode" field
     * 
     * @param array $data
     * @return array $data
     */
    protected function splitCityAndCountry($data)
    {
        if (isset($data['cityCode'])) {
            list($data['city'], $data['country']) = explode(',', $data['cityCode']);
            unset($data['cityCode']);
        }
        return $data;
    }
    
    /**
     * Retrieves a single contact by contact_id
     * 
     * @param int $id
     * @return array $row = row of data
     */
    public function getContactById($id)
    {
        $this->select([self::$primaryKey => $id])->current();
    }
    
}
