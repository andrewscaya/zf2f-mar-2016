<?php
namespace Data\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\TableGateway\TableGateway;

class ListingsTable extends TableGateway
{
    
	public static $tableName  = 'listings';
	public static $primaryKey = 'listings_id';
	
	// key = form field; value = column name
    protected $onClause;
    protected $adapter;
	protected $formMappings = array(
			'category' 		=> 'category',
			'title' 		=> 'title',
			'price' 		=> 'price',
			'photo'			=> 'photo_filename',
			'expires' 		=> 'date_expires',
			'contactId'		=> 'contact_id',
			'delCode' 		=> 'delete_code',
			'description' 	=> 'description'
	);	

    /**
     * Returns the array of form --> database column mappings
     * 
     * @return array $formMappings
     */
    public function getFormMappings()
    {
        return $this->formMappings;
    }
    
	/**
	 * Inserts posting
	 * @param Array $data = uses form fields
	 * @return boolean $result = TRUE if operation was successful
	 */
	public function add($data)
	{
		$insertData = array();
		foreach ($this->formMappings as $key => $value) {
			$insertData[$value] = $data[$key];
		}
		return $this->insert($insertData);
	}
	
	/**
	 * Updates posting
	 * @param int $id
	 * @param Array $data = uses form fields
	 * @return boolean $result = TRUE if operation was successful
	 */
	public function edit($id, $data)
	{
		$insertData = array();
		foreach ($this->formMappings as $key => $value) {
			$insertData[$value] = $data[$key];
		}
		return $this->update($insertData, [self::$primaryKey => $id]);
	}
	
	// SELECT * FROM listings AS L
    // JOIN contacts AS C ON L.contacts_id = C.contacts_id
    // ORDER BY L.listings_id DESC
    // LIMIT 1
	public function getLatestListing()
	{
		$select = $this->getJoinSelect();
		$select->order('L.' . self::$primaryKey, 'DESC')
               ->limit(1);        
		return $this->selectWith($select)->current();
	}

	// SELECT * FROM listings AS L
    // JOIN contacts AS C ON L.contacts_id = C.contacts_id
    // WHERE L.category = $category
    // ORDER BY L.title DESC
	public function getListingsByCategory($category = NULL)
	{
        // build where clause
		$where = new Where();
		$where->equalTo('category', $category);
        // build SQL
		$select = $this->getJoinSelect();
		$select->order('L.title', 'ASC')
               ->where($where);
		return $this->selectWith($select);
	}

	// SELECT * FROM listings AS L
    // JOIN contacts AS C ON L.contacts_id = C.contacts_id
	// WHERE L.listings_id = $id 
    // LIMIT 1
	public function getListingById($id = 1)
	{
        // build where clause
		$where = new Where();
		$where->equalTo(self::primaryKey, $id);
		$select->where($where);
        // build SQL
		$select = $this->getJoinSelect();
		$select->limit(1)
               ->where($where);
		return $this->selectWith($select)->current();	
	}

	/**
	 * Retrieves listings from both listings table and contacts tables 
     * with fields = form fields
	 * @param int $id
	 * @return array $formData
	 */
	public function getListingForForm($id)
	{
		$listing = $this->getListingById($id);
		$formData = array();
		if ($listing) {
			foreach ($this->formMappings as $key => $value) {
				$formData[$key] = $listing[$value];
			}
		}
		return $formData;
	}
    
    protected function getJoinSelect()
    {
        $on = sprintf('L.%s = C.%s', ContactsTable::$primaryKey, ContactsTable::$primaryKey);
		$adapter = $this->getAdapter();
        $sql = new Sql($adapter);
		$select = $sql->select();
		$select->from(['L' => self::$tableName])
               ->join(['C' => ContactsTable::$tableName], $on);
        return $select;
    }
}
